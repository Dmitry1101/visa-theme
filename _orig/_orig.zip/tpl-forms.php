<?php /* Template Name: Gravity Forms*/ get_header(); ?>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=27]' ); ?>

		</div>
	</div>


<?php /*
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=2]' ); ?>
		</div>
	</div>

	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=57]' ); ?>
		</div>
	</div>

	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=4]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=5]' ); ?>
		</div>
	</div>

	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=6]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=7]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=8]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=9]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=10]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=11]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=12]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=13]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=14]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=15]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=16]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=17]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=18]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=19]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=20]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=21]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=22]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=23]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=24]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=25]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=26]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=27]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=28]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=29]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=30]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=31]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=32]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=33]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=34]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=35]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=36]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=37]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=38]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=39]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=40]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=41]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=42]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=43]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=44]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=45]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=46]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=47]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=48]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=49]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=50]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=51]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=52]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=53]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=54]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=55]' ); ?>
		</div>
	</div>
	<div id="gravityforms-block">
		<div class="row">
			<?php echo do_shortcode( '[gravityform id=56]' ); ?>
		</div>
	</div>
*/?>
<?php
get_footer();
